﻿namespace SoundAPI
{
    public class ExampleModule : ETGModule
    {
        public override void Init()
        {
            SoundManager.Init();
        }

        public override void Start()
        {
            SoundManager.AddCustomSwitchData("WPN_Guns", "Magnum", "Play_WPN_gun_shot_01", "Play_wpn_jk47_droop_01");
        }

        public override void Exit()
        {
        }
    }
}
